import { Router } from 'express'

export function leaderboardRouter(pool){
  const r = Router()

  r.get('/', async (req,res) => {
    const sql = `
      WITH wins AS (
        SELECT winner_player_id AS player_id, COUNT(*)::int AS wins
        FROM matches
        WHERE winner_player_id IS NOT NULL
        GROUP BY winner_player_id
      ),
      losses AS (
        SELECT
          CASE
            WHEN winner_player_id = player1_id THEN player2_id
            WHEN winner_player_id = player2_id THEN player1_id
            ELSE NULL
          END AS player_id,
          COUNT(*)::int AS losses
        FROM matches
        WHERE winner_player_id IS NOT NULL
        GROUP BY 1
      )
      SELECT
        p.id,
        p.name,
        p.skill,
        p.status,
        COALESCE(w.wins,0) AS wins,
        COALESCE(l.losses,0) AS losses
      FROM players p
      LEFT JOIN wins w ON p.id = w.player_id
      LEFT JOIN losses l ON p.id = l.player_id
      ORDER BY wins DESC, losses ASC, p.name ASC
      LIMIT 200
    `
    const { rows } = await pool.query(sql)
    res.json(rows)
  })

  return r
}
