import { useEffect, useMemo, useState } from 'react'
import { api } from '../lib/api'

export default function Leaderboard(){
  const [rows,setRows]=useState([])
  const [err,setErr]=useState(null)
  const [loading,setLoading]=useState(true)

  useEffect(()=>{
    let alive=true
    setLoading(true); setErr(null)
    api.get('/leaderboard')
      .then(r=>{ if(!alive) return; setRows(r.data || []) })
      .catch(e=>{ if(!alive) return; setErr(e?.response?.data?.error || e.message || 'Failed') })
      .finally(()=>{ if(!alive) return; setLoading(false) })
    return ()=>{ alive=false }
  },[])

  const top = useMemo(()=>rows.slice(0,50),[rows])

  return (
    <div className="card">
      <div className="row" style={{justifyContent:'space-between', alignItems:'center'}}>
        <div>
          <div className="h1">Leaderboard</div>
          <div className="muted">Wins are computed from completed matches.</div>
        </div>
      </div>

      <div style={{height:12}} />

      {loading && <div className="muted">Loading…</div>}
      {err && <div className="error">{err}</div>}

      {!loading && !err && (
        <div style={{display:'grid', gap:8}}>
          {top.map((p,i)=>(
            <div key={p.id} className="card" style={{padding:12}}>
              <div className="row" style={{justifyContent:'space-between', alignItems:'center'}}>
                <div>
                  <div style={{fontWeight:700}}>{i+1}. {p.name}</div>
                  <div className="muted" style={{fontSize:12}}>
                    {p.skill || '—'} {p.status ? `• ${p.status}` : ''}
                  </div>
                </div>
                <div className="row" style={{gap:10}}>
                  <div className="pill">W {p.wins}</div>
                  <div className="pill">L {p.losses}</div>
                </div>
              </div>
            </div>
          ))}
          {top.length===0 && <div className="muted">No players yet. Create a player, then record matches.</div>}
        </div>
      )}
    </div>
  )
}
